﻿using API.Model;


namespace API.Repositories.Interface
{
    public interface IBorrowRepository : IGeneralRepository<Borrow, int>
    {
    }
}
