﻿using API.Models;
using System.Data;

namespace API.Repositories.Interface
{
    public interface IRolesRepository : IGeneralRepository<Roles, int>
    {

    }
}